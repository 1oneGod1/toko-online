<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['product']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['product']); ?>
<?php foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
    <!-- Discussions Section -->
    <div class="mb-5">
        <h4 class="mb-3">Diskusi Produk (<?php echo e($product->discussions->where('parent_id', null)->count()); ?>)</h4>

        <!-- Form for starting a new discussion -->
        <?php if(auth()->guard()->check()): ?>
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">Mulai Diskusi Baru</h5>
                    <form action="<?php echo e(route('discussions.store', $product)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <textarea name="message" class="form-control" rows="3" placeholder="Ada yang ingin ditanyakan tentang produk ini?" required></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Kirim Pertanyaan</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <a href="<?php echo e(route('login')); ?>">Masuk</a> untuk memulai diskusi.
            </div>
        <?php endif; ?>

        <!-- Display existing discussions -->
        <?php $__empty_1 = true; $__currentLoopData = $product->discussions->where('parent_id', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="d-flex mb-3 border-bottom pb-3">
                <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($discussion->user->name)); ?>&background=random" class="rounded-circle me-3" style="width: 50px; height: 50px;" alt="<?php echo e($discussion->user->name); ?>">
                <div class="w-100">
                    <div class="d-flex justify-content-between">
                        <h6 class="fw-bold"><?php echo e($discussion->user->name); ?></h6>
                        <small class="text-muted"><?php echo e($discussion->created_at->diffForHumans()); ?></small>
                    </div>
                    <p class="mt-2 mb-1"><?php echo e($discussion->message); ?></p>
                    
                    <!-- Replies -->
                    <?php if($discussion->replies->isNotEmpty()): ?>
                        <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex mt-3 ms-4">
                                <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($reply->user->name)); ?>&background=random" class="rounded-circle me-3" style="width: 40px; height: 40px;" alt="<?php echo e($reply->user->name); ?>">
                                <div class="w-100">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="fw-bold"><?php echo e($reply->user->name); ?></h6>
                                        <small class="text-muted"><?php echo e($reply->created_at->diffForHumans()); ?></small>
                                    </div>
                                    <p class="mb-1"><?php echo e($reply->message); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <!-- Reply Form -->
                    <?php if(auth()->guard()->check()): ?>
                        <a class="small text-decoration-none" data-bs-toggle="collapse" href="#reply-form-<?php echo e($discussion->id); ?>" role="button" aria-expanded="false" aria-controls="reply-form-<?php echo e($discussion->id); ?>">
                            Balas
                        </a>
                        <div class="collapse mt-2" id="reply-form-<?php echo e($discussion->id); ?>">
                            <form action="<?php echo e(route('discussions.store', $product)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="parent_id" value="<?php echo e($discussion->id); ?>">
                                <div class="d-flex">
                                    <input type="text" name="message" class="form-control form-control-sm" placeholder="Tulis balasan..." required>
                                    <button type="submit" class="btn btn-sm btn-primary ms-2">Kirim</button>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Belum ada diskusi untuk produk ini.</p>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\laragon\www\toko-online\resources\views/components/product/discussions.blade.php ENDPATH**/ ?>