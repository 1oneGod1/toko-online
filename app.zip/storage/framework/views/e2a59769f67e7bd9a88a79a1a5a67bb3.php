<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Daftar Produk']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Daftar Produk']); ?>
    <div class="container">
        <!-- Form untuk Filter, Pencarian, dan Urutan -->
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Filter Produk</h5>
                <form action="<?php echo e(route('products.index')); ?>" method="GET">
                    <div class="row g-3 align-items-end">
                        <div class="col-lg-4 col-md-12">
                            <label for="search" class="form-label">Cari Produk</label>
                            <input type="text" class="form-control" id="search" name="search" placeholder="Nama atau deskripsi..." value="<?php echo e(request('search')); ?>">
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <label for="min_price" class="form-label">Harga Min.</label>
                            <input type="number" class="form-control" id="min_price" name="min_price" placeholder="Rp 0" value="<?php echo e(request('min_price')); ?>">
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <label for="max_price" class="form-label">Harga Max.</label>
                            <input type="number" class="form-control" id="max_price" name="max_price" placeholder="Rp 1.000.000" value="<?php echo e(request('max_price')); ?>">
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <label for="sort" class="form-label">Urutkan</label>
                            <select class="form-select" id="sort" name="sort">
                                <option value="">Paling Sesuai</option>
                                <option value="harga_asc" <?php if(request('sort') == 'harga_asc'): echo 'selected'; endif; ?>>Harga Terendah</option>
                                <option value="harga_desc" <?php if(request('sort') == 'harga_desc'): echo 'selected'; endif; ?>>Harga Tertinggi</option>
                                <option value="nama_asc" <?php if(request('sort') == 'nama_asc'): echo 'selected'; endif; ?>>Nama A-Z</option>
                                <option value="nama_desc" <?php if(request('sort') == 'nama_desc'): echo 'selected'; endif; ?>>Nama Z-A</option>
                            </select>
                        </div>
                        <div class="col-lg-2 col-md-6 d-grid">
                            <button type="submit" class="btn btn-primary">Terapkan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">Daftar Produk (<?php echo e($products->total()); ?> produk)</h1>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-primary">
                    + Tambah Produk
                </a>
            <?php endif; ?>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4 col-xl-3 mb-4">
                    <div class="card h-100 product-card">
                        <span class="badge bg-primary position-absolute top-0 start-0 m-2"><?php echo e($product->category->name); ?></span>
                        <img src="<?php echo e(Str::startsWith($product->image, 'http') ? $product->image : asset('storage/' . $product->image)); ?>" 
                             class="card-img-top" 
                             alt="<?php echo e($product->name); ?>" 
                             style="height: 200px; object-fit: cover;"
                             onerror="this.onerror=null;this.src='https://placehold.co/600x400/EBF4FA/313131?text=Gambar+Rusak';">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text text-muted flex-grow-1 small"><?php echo e(Str::limit($product->description, 100)); ?></p>
                            <p class="card-text h5 text-primary">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                            <div class="mt-auto pt-2">
                                <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-dark w-100 mb-2">Lihat Detail</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-outline-secondary w-100">Ubah</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-warning text-center">
                        <h4 class="alert-heading">Tidak Ada Produk</h4>
                        <p>Produk yang Anda cari tidak ditemukan. Coba ubah kata kunci atau filter Anda.</p>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Atur Ulang Filter</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($products->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\toko-online\resources\views/products/list.blade.php ENDPATH**/ ?>