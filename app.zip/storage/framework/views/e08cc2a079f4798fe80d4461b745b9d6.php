<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Dashboard Admin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard Admin']); ?>
    <div class="container py-4">
        <h1 class="h3 mb-4">Dashboard Admin</h1>
        
        <!-- Statistik Utama -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-bg-primary mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Pesanan</h5>
                        <p class="card-text fs-2"><?php echo e($stats['total_orders']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-bg-warning mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Pesanan Pending</h5>
                        <p class="card-text fs-2"><?php echo e($stats['pending_orders']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-bg-success mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Produk</h5>
                        <p class="card-text fs-2"><?php echo e($stats['total_products']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-bg-info mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Pengguna</h5>
                        <p class="card-text fs-2"><?php echo e($stats['total_users']); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Pesanan Terbaru -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Pesanan Terbaru</h5>
                            <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Pelanggan</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>#<?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->user->name); ?></td>
                                        <td>
                                            <span class="badge rounded-pill text-bg-<?php echo e($order->status == 'pending' ? 'warning' : ($order->status == 'completed' ? 'success' : 'info')); ?>">
                                                <?php echo e(ucfirst($order->status)); ?>

                                            </span>
                                        </td>
                                        <td>Rp <?php echo e(number_format($order->total_amount)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">Belum ada pesanan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Produk dengan Stok Menipis -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Produk dengan Stok Menipis</h5>
                            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Nama Produk</th>
                                    <th>Kategori</th>
                                    <th>Sisa Stok</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $low_stock_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->category->name); ?></td>
                                        <td>
                                            <span class="badge text-bg-<?php echo e($product->stock == 0 ? 'danger' : 'warning'); ?>">
                                                <?php echo e($product->stock); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">Tidak ada produk dengan stok menipis.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Link Cepat ke Menu Admin -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Menu Admin</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-primary w-100 p-3">
                                    <i class="bi bi-plus-circle"></i> Tambah Produk
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-success w-100 p-3">
                                    <i class="bi bi-box-seam"></i> Manajemen Produk
                                </a>
                            </div>                            <div class="col-md-3">
                                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-primary w-100 p-3">
                                    <i class="bi bi-plus-circle"></i> Tambah Produk Baru
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-success w-100 p-3">
                                    <i class="bi bi-box-seam"></i> Manajemen Stok
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline-warning w-100 p-3">
                                    <i class="bi bi-list-check"></i> Kelola Pesanan
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-info w-100 p-3">
                                    <i class="bi bi-people"></i> Kelola Pengguna
                                </a>
                            </div>
                        </div>
                        
                        <div class="row g-3 mt-2">
                            <div class="col-md-3">
                                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-secondary w-100 p-3">
                                    <i class="bi bi-tags"></i> Kelola Kategori
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('admin.landing.index')); ?>" class="btn btn-outline-primary w-100 p-3">
                                    <i class="bi bi-brush"></i> Pengaturan Halaman
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\toko-online\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>