<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Keranjang Belanja']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Keranjang Belanja']); ?>
    <div class="container py-4">
        <h1 class="mb-4">Keranjang Belanja Anda</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(empty($cart)): ?>
            <div class="alert alert-warning">
                Keranjang belanja Anda masih kosong.
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary ms-3">Mulai Belanja</a>
            </div>
        <?php else: ?>
            <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col" class="ps-4">Produk</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col" style="width: 150px;">Jumlah</th>
                                    <th scope="col" class="text-end">Subtotal</th>
                                    <th scope="col" class="text-center pe-4">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total = 0 ?>
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $total += $details['price'] * $details['quantity'] ?>
                                    <tr>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e(Str::startsWith($details['image'], ['http', 'https']) ? $details['image'] : asset('storage/' . ($details['image'] ?? 'default.jpg'))); ?>" 
                                                     class="img-fluid rounded me-3" 
                                                     style="width: 60px; height: 60px; object-fit: cover;"
                                                     alt="<?php echo e($details['name']); ?>"
                                                     onerror="this.src='https://placehold.co/60x60?text=No+Image'">
                                                <div>
                                                    <h6 class="mb-0"><?php echo e($details['name']); ?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td>Rp <?php echo e(number_format($details['price'], 0, ',', '.')); ?></td>
                                        <td>
                                            <input type="number" name="quantities[<?php echo e($id); ?>]" class="form-control form-control-sm text-center" value="<?php echo e($details['quantity']); ?>" min="1">
                                        </td>
                                        <td class="text-end">Rp <?php echo e(number_format($details['price'] * $details['quantity'], 0, ',', '.')); ?></td>
                                        <td class="text-center pe-4">
                                            <a href="<?php echo e(route('cart.remove', $id)); ?>" class="btn btn-sm btn-outline-danger" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer bg-white">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-arrow-repeat"></i> Perbarui Keranjang
                                </button>
                                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">Lanjut Belanja</a>
                            </div>
                            <div class="text-end">
                                <h5 class="mb-0">Total: Rp <?php echo e(number_format($total, 0, ',', '.')); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="text-end mt-4">
                <a href="#" class="btn btn-success btn-lg">
                    <i class="bi bi-wallet2"></i> Lanjutkan ke Pembayaran
                </a>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\toko-online\resources\views/cart/index.blade.php ENDPATH**/ ?>