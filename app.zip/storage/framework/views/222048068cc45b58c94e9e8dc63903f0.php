<div>
    <!-- Top Announcement Bar -->
    <div class="top-bar">
        NEW CUSTOMERS SAVE 10% WITH THE CODE: GET10
    </div>

    <!-- Main Navbar -->
    <nav class="navbar navbar-expand-lg modern-navbar">
        <div class="container-fluid">
            <!-- Logo -->
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Toko Online</a>

            <!-- Centered Navigation Links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('products.index') ? 'active' : ''); ?>" href="<?php echo e(route('products.index')); ?>">Produk</a>
                    </li>
                    <!-- Add other main navigation links here -->
                </ul>
            </div>

            <!-- Right-side Action Icons -->
            <div class="navbar-actions">
                <button class="btn" id="theme-switcher" type="button" aria-label="Toggle theme">
                    <i class="bi bi-moon-fill"></i>
                </button>

                <a href="#" class="nav-link" aria-label="Search">
                    <i class="bi bi-search"></i>
                </a>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="nav-link" aria-label="Login">
                        <i class="bi bi-person"></i>
                    </a>
                <?php else: ?>
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="User menu">
                            <i class="bi bi-person"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="#">Profil Saya</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('orders.index')); ?>">Riwayat Pesanan</a></li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Admin Dashboard</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    Keluar
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>

                <a href="<?php echo e(route('cart.index')); ?>" class="nav-link" aria-label="Cart">
                    <i class="bi bi-bag"></i>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(session('cart') && count(session('cart')) > 0): ?>
                            <span class="badge bg-primary rounded-pill" style="font-size: 0.6rem; position: relative; top: -10px; left: -5px;">
                                <?php echo e(count(session('cart'))); ?>

                            </span>
                        <?php endif; ?>
                    <?php endif; ?>
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </div>
    </nav>
</div><?php /**PATH C:\laragon\www\toko-online\resources\views/components/layouts/navbar.blade.php ENDPATH**/ ?>