<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['product']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['product']); ?>
<?php foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="product-reviews mb-5">
    <h3 class="h5 mb-4">Ulasan Produk</h3>
    
    <!-- Review Stats -->
    <div class="row align-items-center mb-4">
        <div class="col-md-3 text-center">
            <div class="display-4 fw-bold text-warning mb-1"><?php echo e(number_format($product->average_rating, 1)); ?></div>
            <div class="mb-2">
                <?php if (isset($component)) { $__componentOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product.star-rating','data' => ['rating' => $product->average_rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product.star-rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->average_rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4)): ?>
<?php $attributes = $__attributesOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4; ?>
<?php unset($__attributesOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4)): ?>
<?php $component = $__componentOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4; ?>
<?php unset($__componentOriginal8c90b1fde3b4d5a42d6bc20a36d2e6d4); ?>
<?php endif; ?>
            </div>
            <div class="text-muted"><?php echo e($product->rating_count); ?> ulasan</div>
        </div>
        <div class="col-md-9">
            <div class="d-flex align-items-center mb-2">
                <div class="text-nowrap me-3">5 <i class="bi bi-star-fill text-warning"></i></div>
                <div class="progress flex-grow-1" style="height: 8px;">
                    <?php $fiveStarPercent = $product->rating_count > 0 ? ($product->reviews->where('rating', 5)->count() / $product->rating_count) * 100 : 0; ?>
                    <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($fiveStarPercent); ?>%"></div>
                </div>
                <div class="ms-3 text-muted small"><?php echo e($product->reviews->where('rating', 5)->count()); ?></div>
            </div>
            <div class="d-flex align-items-center mb-2">
                <div class="text-nowrap me-3">4 <i class="bi bi-star-fill text-warning"></i></div>
                <div class="progress flex-grow-1" style="height: 8px;">
                    <?php $fourStarPercent = $product->rating_count > 0 ? ($product->reviews->where('rating', 4)->count() / $product->rating_count) * 100 : 0; ?>
                    <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($fourStarPercent); ?>%"></div>
                </div>
                <div class="ms-3 text-muted small"><?php echo e($product->reviews->where('rating', 4)->count()); ?></div>
            </div>
            <div class="d-flex align-items-center mb-2">
                <div class="text-nowrap me-3">3 <i class="bi bi-star-fill text-warning"></i></div>
                <div class="progress flex-grow-1" style="height: 8px;">
                    <?php $threeStarPercent = $product->rating_count > 0 ? ($product->reviews->where('rating', 3)->count() / $product->rating_count) * 100 : 0; ?>
                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($threeStarPercent); ?>%"></div>
                </div>
                <div class="ms-3 text-muted small"><?php echo e($product->reviews->where('rating', 3)->count()); ?></div>
            </div>
            <div class="d-flex align-items-center mb-2">
                <div class="text-nowrap me-3">2 <i class="bi bi-star-fill text-warning"></i></div>
                <div class="progress flex-grow-1" style="height: 8px;">
                    <?php $twoStarPercent = $product->rating_count > 0 ? ($product->reviews->where('rating', 2)->count() / $product->rating_count) * 100 : 0; ?>
                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo e($twoStarPercent); ?>%"></div>
                </div>
                <div class="ms-3 text-muted small"><?php echo e($product->reviews->where('rating', 2)->count()); ?></div>
            </div>
            <div class="d-flex align-items-center">
                <div class="text-nowrap me-3">1 <i class="bi bi-star-fill text-warning"></i></div>
                <div class="progress flex-grow-1" style="height: 8px;">
                    <?php $oneStarPercent = $product->rating_count > 0 ? ($product->reviews->where('rating', 1)->count() / $product->rating_count) * 100 : 0; ?>
                    <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo e($oneStarPercent); ?>%"></div>
                </div>
                <div class="ms-3 text-muted small"><?php echo e($product->reviews->where('rating', 1)->count()); ?></div>
            </div>
        </div>
    </div>
    
    <!-- User Review Form -->
    <?php if(auth()->guard()->check()): ?>
        <?php $userReview = $product->reviews->where('user_id', auth()->id())->first(); ?>
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="mb-3"><?php echo e($userReview ? 'Edit Ulasan Anda' : 'Berikan Ulasan'); ?></h5>
                <form action="<?php echo e(route('reviews.store', $product)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Rating</label>
                        <div class="rating-input">
                            <div class="d-flex">
                                <?php for($i = 5; $i >= 1; $i--): ?>
                                    <div class="me-2">
                                        <input type="radio" name="rating" id="rating-<?php echo e($i); ?>" value="<?php echo e($i); ?>" <?php echo e(($userReview && $userReview->rating == $i) ? 'checked' : ''); ?> required>
                                        <label for="rating-<?php echo e($i); ?>" class="btn btn-outline-warning">
                                            <?php echo e($i); ?> <i class="bi bi-star-fill"></i>
                                        </label>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Komentar</label>
                        <textarea class="form-control" id="comment" name="comment" rows="3" placeholder="Bagikan pendapat Anda tentang produk ini"><?php echo e($userReview ? $userReview->comment : ''); ?></textarea>
                    </div>
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e($userReview ? 'Perbarui Ulasan' : 'Kirim Ulasan'); ?>

                        </button>
                        <?php if($userReview): ?>
                            <form action="<?php echo e(route('reviews.destroy', $userReview)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus ulasan?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger">Hapus Ulasan</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info mb-4">
            <p class="mb-0">
                <i class="bi bi-info-circle"></i> Silahkan <a href="<?php echo e(route('login')); ?>">masuk</a> untuk memberikan ulasan.
            </p>
        </div>
    <?php endif; ?>
    
    <!-- Reviews List -->
    <?php if($product->rating_count > 0): ?>
        <div class="reviews-list">
            <?php $__currentLoopData = $product->reviews()->with('user')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card shadow-sm mb-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <div>
                                <div class="d-flex align-items-center">
                                    <span class="fw-bold me-2"><?php echo e($review->user->name); ?></span>
                                    <span class="badge bg-light text-dark">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= $review->rating): ?>
                                                <i class="bi bi-star-fill text-warning"></i>
                                            <?php else: ?>
                                                <i class="bi bi-star text-warning"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </span>
                                </div>
                                <small class="text-muted"><?php echo e($review->created_at->diffForHumans()); ?></small>
                            </div>
                            <?php if(auth()->check() && (auth()->id() === $review->user_id || auth()->user()->isAdmin())): ?>
                                <div>
                                    <form action="<?php echo e(route('reviews.destroy', $review)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm text-danger" onclick="return confirm('Yakin ingin menghapus ulasan ini?')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                        <p class="mb-0"><?php echo e($review->comment); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="text-center py-4 text-muted">
            <p class="mb-0">Belum ada ulasan untuk produk ini.</p>
        </div>
    <?php endif; ?>
</div>

<style>
.rating-input input[type="radio"] {
    display: none;
}

.rating-input label {
    cursor: pointer;
}

.rating-input input[type="radio"]:checked + label {
    background-color: #ffc107;
    color: #212529;
    border-color: #ffc107;
}

.star-rating {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-end;
}
.star-rating input {
    display: none;
}
.star-rating label {
    font-size: 2rem;
    color: #ddd;
    cursor: pointer;
}
.star-rating input:checked ~ label,
.star-rating label:hover,
.star-rating label:hover ~ label {
    color: #ffc107;
}
</style><?php /**PATH C:\laragon\www\toko-online\resources\views/components/product/reviews.blade.php ENDPATH**/ ?>