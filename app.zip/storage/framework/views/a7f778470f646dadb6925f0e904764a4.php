<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['rating']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['rating']); ?>
<?php foreach (array_filter((['rating']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="star-rating d-inline-block">
    <?php for($i = 1; $i <= 5; $i++): ?>
        <?php if($i <= floor($rating)): ?>
            <i class="bi bi-star-fill text-warning"></i>
        <?php elseif($i - 0.5 <= $rating): ?>
            <i class="bi bi-star-half text-warning"></i>
        <?php else: ?>
            <i class="bi bi-star text-warning"></i>
        <?php endif; ?>
    <?php endfor; ?>
</div><?php /**PATH C:\laragon\www\toko-online\resources\views/components/product/star-rating.blade.php ENDPATH**/ ?>