<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => ''.e(isset($product) ? 'Ubah Produk' : 'Tambah Produk').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(isset($product) ? 'Ubah Produk' : 'Tambah Produk').'']); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card shadow-sm">
                    <div class="card-header bg-white pb-0 border-0">
                         <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h4 mb-0"><?php echo e(isset($product) ? 'Ubah Produk' : 'Tambah Produk'); ?></h1>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
                                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-manage">Kelola Kategori</a>
                            <?php endif; ?>
                        </div>
                        <hr>
                    </div>
                    <div class="card-body pt-0">
                        
                        <form action="<?php echo e(isset($product) ? route('products.update', $product) : route('products.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <?php if(isset($product)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            <div class="mb-3">
                                <label for="name" class="form-label">Nama Produk</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $product->name ?? '')); ?>" placeholder="Contoh: Kemeja Flanel" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Deskripsi</label>
                                <textarea class="form-control" id="description" name="description" rows="4" placeholder="Deskripsi singkat produk..." required><?php echo e(old('description', $product->description ?? '')); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="price" class="form-label">Harga (Rp)</label>
                                <input type="number" class="form-control" id="price" name="price" value="<?php echo e(old('price', $product->price ?? '')); ?>" placeholder="Contoh: 150000" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="discount_price" class="form-label">Harga Diskon (Rp) <small class="text-muted">(Opsional)</small></label>
                                <input type="number" class="form-control" id="discount_price" name="discount_price" value="<?php echo e(old('discount_price', $product->discount_price ?? '')); ?>" placeholder="Contoh: 120000">
                            </div>
                            
                            <div class="mb-3">
                                <label for="stock" class="form-label">Stok</label>
                                <input type="number" class="form-control" id="stock" name="stock" value="<?php echo e(old('stock', $product->stock ?? 0)); ?>" placeholder="Jumlah stok" required>
                            </div>

                            <div class="mb-3">
                                <label for="category_id" class="form-label">Kategori</label>
                                <select class="form-select" id="category_id" name="category_id" required>
                                    <option value="" disabled selected>Pilih Kategori</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $product->category_id ?? '') == $category->id): echo 'selected'; endif; ?>>
                                            <?php echo e($category->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-4">
                                <label for="photo" class="form-label">Foto Produk</label>
                                <input class="form-control" type="file" id="photo" name="photo">
                            </div>
                            
                            <div class="d-flex justify-content-start">
                                <button type="submit" class="btn btn-save px-4">
                                    <?php echo e(isset($product) ? 'Simpan Perubahan' : 'Simpan'); ?>

                                </button>
                                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-link text-muted ms-3">Batal</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\toko-online\resources\views/products/form.blade.php ENDPATH**/ ?>