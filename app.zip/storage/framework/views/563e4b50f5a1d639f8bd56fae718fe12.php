<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Pengaturan Halaman Utama']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pengaturan Halaman Utama']); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Pengaturan Halaman Utama</h5>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.landing.update')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col-md-8">
                        <!-- Hero Title -->
                        <div class="mb-3">
                            <label for="hero_title" class="form-label">Judul Hero</label>
                            <input type="text" class="form-control" id="hero_title" name="hero_title" value="<?php echo e(old('hero_title', $settings['hero_title'] ?? 'Selamat Datang di Toko Online')); ?>">
                            <?php $__errorArgs = ['hero_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Hero Subtitle -->
                        <div class="mb-3">
                            <label for="hero_subtitle" class="form-label">Subjudul Hero</label>
                            <textarea class="form-control" id="hero_subtitle" name="hero_subtitle" rows="3"><?php echo e(old('hero_subtitle', $settings['hero_subtitle'] ?? 'Temukan ribuan produk berkualitas dengan harga terbaik. Belanja mudah, cepat, dan aman.')); ?></textarea>
                            <?php $__errorArgs = ['hero_subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Hero Button Text -->
                        <div class="mb-3">
                            <label for="hero_button_text" class="form-label">Teks Tombol Hero</label>
                            <input type="text" class="form-control" id="hero_button_text" name="hero_button_text" value="<?php echo e(old('hero_button_text', $settings['hero_button_text'] ?? 'Mulai Belanja Sekarang')); ?>">
                            <?php $__errorArgs = ['hero_button_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!-- Hero Image -->
                        <div class="mb-3">
                            <label for="hero_image" class="form-label">Gambar Latar Hero</label>
                            <input class="form-control" type="file" id="hero_image" name="hero_image">
                            <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah gambar.</small>
                            <?php $__errorArgs = ['hero_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <?php if(isset($settings['hero_image']) && $settings['hero_image']): ?>
                            <div class="mb-3">
                                <p class="mb-1">Gambar Saat Ini:</p>
                                <img src="<?php echo e(Storage::url($settings['hero_image'])); ?>" alt="Hero Image" class="img-thumbnail" style="max-width: 100%;">
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <p class="mb-1">Tidak ada gambar saat ini.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>


                <button type="submit" class="btn btn-primary mt-3">Simpan Perubahan</button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\toko-online\resources\views/admin/landing/index.blade.php ENDPATH**/ ?>