<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Manajemen Stok Produk']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Manajemen Stok Produk']); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">Manajemen Stok Produk</h1>
            <div>
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Tambah Produk Baru
                </a>
            </div>
        </div>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Daftar Stok Produk</h5>
                <div>
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="toggleEditMode">
                        <i class="bi bi-pencil"></i> Edit Massal
                    </button>
                    <button type="submit" form="stockForm" class="btn btn-sm btn-success d-none" id="saveAllBtn">
                        <i class="bi bi-save"></i> Simpan Semua
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.stock.bulk-update')); ?>" method="POST" id="stockForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">#</th>
                                    <th width="10%">Gambar</th>
                                    <th width="30%">Nama Produk</th>
                                    <th width="15%">Kategori</th>
                                    <th width="15%">Harga</th>
                                    <th width="10%">Stok</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td>
                                            <img src="<?php echo e(Str::startsWith($product->image ?? '', 'http') ? $product->image : asset('storage/' . ($product->image ?? 'default.jpg'))); ?>" 
                                                class="img-thumbnail" 
                                                alt="<?php echo e($product->name); ?>" 
                                                width="50" 
                                                onerror="this.src='https://placehold.co/50x50?text=Produk'">
                                        </td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->category->name); ?></td>
                                        <td>Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                                        <td>
                                            <div class="input-group input-group-sm">
                                                <!-- Displayed when not in edit mode -->
                                                <span class="form-control single-view">
                                                    <span class="badge bg-<?php echo e($product->stock > 10 ? 'success' : ($product->stock > 0 ? 'warning' : 'danger')); ?>">
                                                        <?php echo e($product->stock); ?>

                                                    </span>
                                                </span>
                                                
                                                <!-- Displayed when in edit mode -->
                                                <input type="number" name="stocks[<?php echo e($product->id); ?>]" value="<?php echo e($product->stock); ?>" min="0" class="form-control bulk-edit d-none">
                                            </div>
                                        </td>
                                        <td>
                                            <!-- Quick Stock Update Form -->
                                            <form action="<?php echo e(route('admin.stock.update', $product)); ?>" method="POST" class="d-inline single-view">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="btn-group btn-group-sm">
                                                    <button type="submit" name="stock" value="<?php echo e($product->stock - 1); ?>" class="btn btn-outline-danger" <?php echo e($product->stock <= 0 ? 'disabled' : ''); ?>>
                                                        -1
                                                    </button>
                                                    <button type="submit" name="stock" value="<?php echo e($product->stock + 1); ?>" class="btn btn-outline-success">
                                                        +1
                                                    </button>
                                                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-outline-primary">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                </div>
                                            </form>
                                            
                                            <!-- Hidden in bulk edit mode -->
                                            <span class="bulk-edit d-none">
                                                <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-pencil"></i> Edit
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Belum ada produk.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
                
                <div class="mt-4">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleEditModeBtn = document.getElementById('toggleEditMode');
            const saveAllBtn = document.getElementById('saveAllBtn');
            const singleViewElements = document.querySelectorAll('.single-view');
            const bulkEditElements = document.querySelectorAll('.bulk-edit');
            
            toggleEditModeBtn.addEventListener('click', function() {
                // Toggle button text
                if (toggleEditModeBtn.innerHTML.includes('Edit Massal')) {
                    toggleEditModeBtn.innerHTML = '<i class="bi bi-x-circle"></i> Batal';
                    saveAllBtn.classList.remove('d-none');
                } else {
                    toggleEditModeBtn.innerHTML = '<i class="bi bi-pencil"></i> Edit Massal';
                    saveAllBtn.classList.add('d-none');
                }
                
                // Toggle visibility of elements
                singleViewElements.forEach(el => {
                    el.classList.toggle('d-none');
                });
                
                bulkEditElements.forEach(el => {
                    el.classList.toggle('d-none');
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\toko-online\resources\views/admin/stock/index.blade.php ENDPATH**/ ?>